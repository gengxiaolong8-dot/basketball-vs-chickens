"""Language preferences; no game rules or rendering here."""
import json
from pathlib import Path
import sys
from urllib.parse import parse_qs, urlsplit


PREFERENCE = Path(__file__).resolve().parent / 'data' / 'preferences.json'


def saved_language():
    if sys.platform == 'emscripten':
        import platform
        return parse_qs(urlsplit(str(platform.window.location.href)).query).get('lang', ['en'])[0]
    for argument in sys.argv[1:]:
        if argument.startswith('--lang='):
            return argument.split('=', 1)[1]
    try:
        return json.loads(PREFERENCE.read_text(encoding='utf-8')).get('language', 'en')
    except (OSError, ValueError):
        return 'en'


def select_language(config, language, save=False):
    language = language if language in config['languages'] else 'en'
    config['labels'] = config['languages'][language]
    if save:
        try:
            if sys.platform == 'emscripten':
                import platform
                platform.window.setGameLanguage(language)
            else:
                PREFERENCE.write_text(json.dumps({'language': language}), encoding='utf-8')
        except (OSError, AttributeError):
            pass
    return language
