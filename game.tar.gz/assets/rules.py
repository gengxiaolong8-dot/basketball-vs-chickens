"""Core, Growth and Waves. Each step advances fixed_dt seconds; no pygame."""

from dataclasses import dataclass, field
import json
import math
from pathlib import Path
import random


def load_config():
    with (Path(__file__).parent / "data" / "game.json").open() as source:
        return json.load(source)


@dataclass
class Enemy:
    x: float
    y: float
    hp: float
    hit_cooldown: float = 0.0
    blade_cooldowns: dict = field(default_factory=dict)
    kind: str = "bat"


@dataclass
class Spark:
    x: float
    y: float
    vx: float
    vy: float
    lifetime: float
    damage: float = 0.0


@dataclass
class Gem:
    x: float
    y: float
    xp: int
    attracted: bool = False


@dataclass
class GameEvent:
    kind: str
    x: float
    y: float
    amount: float = 0
    enemy_kind: str = ""


class Game:
    def __init__(self, config=None, rng=None):
        self.config = config if config is not None else load_config()
        self.rng = rng if rng is not None else random.Random()
        self.x = self.y = 0.0
        self.hp = self.config["hero"]["hp"]
        self.enemies = []
        self.sparks = []
        self.kills = 0
        self.elapsed = 0.0
        self.game_over = False
        self.victory = False
        self.boss_spawned = False
        self.spawn_clock = 0.0
        self.spark_clock = 0.0
        self.ring_clock = 0.0
        self.gems = []
        self.level = 1
        self.xp = 0
        self.weapons = {"spark": 1}
        self.passives = {"boots": 0, "heart": 0, "magnet": 0}
        self.cards = []
        self.events = []

    def pop_events(self):
        """Give the window this frame's feedback, then empty the queue."""
        events, self.events = self.events, []
        return events

    @property
    def finished(self):
        return self.game_over or self.victory

    def current_wave(self):
        return max((wave for wave in self.config["waves"] if wave["from"] <= self.elapsed + 1e-9),
                   key=lambda wave: wave["from"])

    def enemy_radius(self, enemy):
        settings = self.config[enemy.kind]
        return settings["radius"] * settings.get("size_scale", 1)

    def _circle_position(self):
        angle = self.rng.uniform(0, math.tau)
        radius = self.config["spawning"]["radius"]
        return self.x + math.cos(angle) * radius, self.y + math.sin(angle) * radius

    def _update_enemy_population(self):
        c = self.config
        boss_kind = c["boss"]["kind"]
        kept = []
        for enemy in self.enemies:
            distance = math.hypot(enemy.x - self.x, enemy.y - self.y)
            if enemy.kind == boss_kind:
                if distance > c["boss"]["return_distance"]:
                    enemy.x, enemy.y = self._circle_position()
                kept.append(enemy)
            elif distance <= c["spawning"]["remove_distance"]:
                kept.append(enemy)
        self.enemies = kept
        if not self.boss_spawned and self.elapsed + 1e-9 >= c["boss"]["spawn_time"]:
            # Reserve the boss's place even if the normal-enemy limit is full.
            if len(self.enemies) >= c["spawning"]["max_alive"]:
                self.enemies.pop()
            x, y = self._circle_position()
            self.enemies.append(Enemy(x, y, c[boss_kind]["hp"], kind=boss_kind))
            self.boss_spawned = True

    @property
    def max_hp(self):
        return self.config["hero"]["hp"] + self.passives["heart"] * self.config["passives"]["heart_hp_per_level"]

    @property
    def speed(self):
        return self.config["hero"]["speed"] * (1 + self.passives["boots"] * self.config["passives"]["boots_speed_per_level"])

    @property
    def magnet_radius(self):
        return self.config["hero"]["magnet_radius"] + self.passives["magnet"] * self.config["passives"]["magnet_radius_per_level"]

    @property
    def xp_needed(self):
        return self.config["growth"]["xp_first"] + (self.level - 1) * self.config["growth"]["xp_increase"]

    def weapon_stats(self, weapon, level=None):
        level = self.weapons.get(weapon, 0) if level is None else level
        settings = self.config[weapon]
        extra = max(0, level - 1)
        stats = {"damage": settings["damage"] + extra * settings["damage_per_level"]}
        if weapon == "spark":
            stats.update(interval=settings["interval"] - extra * settings["interval_per_level"],
                         count=settings["count"] + sum(level >= n for n in settings["extra_spark_levels"]))
        elif weapon == "blades":
            stats["count"] = settings["count"] + sum(level >= n for n in settings["extra_blade_levels"])
        else:
            stats["radius"] = settings["radius"] + extra * settings["radius_per_level"]
        return stats

    def blade_positions(self):
        if not self.weapons.get("blades"):
            return []
        count = self.weapon_stats("blades")["count"]
        radius = self.config["blades"]["orbit_radius"]
        phase = self.elapsed / self.config["blades"]["period"] * math.tau
        return [(self.x + math.cos(phase + i * math.tau / count) * radius,
                 self.y + math.sin(phase + i * math.tau / count) * radius)
                for i in range(count)]

    def award_xp(self, amount):
        self.xp += amount
        self._level_up_if_ready()

    def _level_up_if_ready(self):
        if self.finished or self.cards or self.xp < self.xp_needed:
            return
        self.xp -= self.xp_needed
        self.level += 1
        self.events.append(GameEvent("level_up", self.x, self.y))
        growth = self.config["growth"]
        eligible = [name for name in ("spark", "blades", "ring")
                    if self.weapons.get(name, 0) < growth["max_level"] and
                    (name in self.weapons or len(self.weapons) < growth["max_weapons"])]
        eligible += [name for name, level in self.passives.items() if level < growth["max_level"]]
        if not eligible:
            self.cards = ["heal"] * growth["card_count"]
        else:
            self.cards = self.rng.sample(eligible, min(len(eligible), growth["card_count"]))
            # Keep three clickable cards even when only one or two upgrades remain.
            while len(self.cards) < growth["card_count"]:
                self.cards.append(self.rng.choice(eligible))

    def choose_card(self, index):
        if self.finished or not 0 <= index < len(self.cards):
            return False
        choice = self.cards[index]
        if choice == "heal":
            self.hp = min(self.max_hp, self.hp + self.config["growth"]["fallback_heal"])
        elif choice in self.passives:
            self.passives[choice] += 1
            if choice == "heart":
                self.hp = min(self.max_hp, self.hp + self.config["passives"]["heart_heal_per_level"])
        else:
            self.weapons[choice] = self.weapons.get(choice, 0) + 1
        self.cards = []
        # Excess XP can open another choice, one level at a time.
        self._level_up_if_ready()
        return True

    def card_details(self, choice):
        names = self.config["labels"]["names"]
        if choice == "heal":
            heal = self.config["growth"]["fallback_heal"]
            return f"Pump Up: Heal {heal} HP", "Restore the basketball's health"
        level = self.weapons.get(choice, self.passives.get(choice, 0)) + 1
        if choice in ("spark", "blades", "ring"):
            stats = self.weapon_stats(choice, level)
            if choice == "spark":
                text = f'{stats["count"]} shots, {stats["damage"]} dmg, {stats["interval"]:.2f}s'
            elif choice == "blades":
                text = f'{stats["count"]} orbit balls, {stats["damage"]} dmg'
            else:
                text = f'{stats["damage"]} dmg, {stats["radius"]} px, {self.config["ring"]["interval"]:g}s'
        elif choice == "boots":
            text = f'+{self.config["passives"]["boots_speed_per_level"] * 100:g}% base rolling speed'
        elif choice == "heart":
            p = self.config["passives"]
            text = f'+{p["heart_hp_per_level"]} max HP, heal {p["heart_heal_per_level"]}'
        else:
            text = f'+{self.config["passives"]["magnet_radius_per_level"]} px gem pickup range'
        return f'{names[choice]} - Lv {level}', text

    def _damage(self, bat, damage):
        if bat.hp <= 0:
            return
        bat.hp -= damage
        self.events.append(GameEvent("hit", bat.x, bat.y, damage, bat.kind))
        if bat.hp <= 0:
            self.kills += 1
            self.events.append(GameEvent("death", bat.x, bat.y, enemy_kind=bat.kind))
            xp = self.config[bat.kind]["xp"]
            if xp > 0:
                self.gems.append(Gem(bat.x, bat.y, xp))

    def spawn_enemies(self):
        settings = self.config["spawning"]
        wave = self.current_wave()
        count = max(0, min(wave["minimum_alive"] - len(self.enemies),
                           settings["max_per_second"],
                           settings["max_alive"] - len(self.enemies)))
        for _ in range(count):
            kind = self.rng.choice(wave["types"])
            x, y = self._circle_position()
            self.enemies.append(Enemy(x, y, self.config[kind]["hp"], kind=kind))

    def step(self, target=None):
        """target is a world position, or None to stand still."""
        if self.finished or self.cards:
            return
        c = self.config
        dt = c["fixed_dt"]
        if self.hp <= 0:
            self.game_over = True
            self.events.append(GameEvent("game_over", self.x, self.y))
            return
        self.elapsed += dt
        # Reaching the survival time ends the run before another enemy hit.
        if self.elapsed + 1e-9 >= c["survival_seconds"]:
            self.elapsed = c["survival_seconds"]
            self.victory = True
            self.events.append(GameEvent("victory", self.x, self.y))
            return
        if target is not None:
            dx, dy = target[0] - self.x, target[1] - self.y
            distance = math.hypot(dx, dy)
            if distance > c["controls"]["stop_distance"]:
                travel = min(self.speed * dt,
                             distance - c["controls"]["stop_distance"])
                self.x += dx / distance * travel
                self.y += dy / distance * travel

        self._update_enemy_population()
        self.spawn_clock += dt
        if self.spawn_clock + 1e-9 >= c["spawning"]["interval"]:
            self.spawn_clock -= c["spawning"]["interval"]
            self.spawn_enemies()

        for bat in self.enemies:
            dx, dy = self.x - bat.x, self.y - bat.y
            distance = math.hypot(dx, dy)
            if distance:
                travel = min(distance, c[bat.kind]["speed"] * dt)
                bat.x += dx / distance * travel
                bat.y += dy / distance * travel
            bat.hit_cooldown = max(0, bat.hit_cooldown - dt)
            bat.blade_cooldowns = {i: time - dt for i, time in bat.blade_cooldowns.items() if time > dt}

        self.spark_clock = max(0, self.spark_clock - dt)
        if self.enemies and self.spark_clock <= 1e-9:
            stats = self.weapon_stats("spark")
            nearest = min(self.enemies, key=lambda b: math.hypot(b.x - self.x, b.y - self.y))
            dx, dy = nearest.x - self.x, nearest.y - self.y
            distance = math.hypot(dx, dy)
            vx, vy = (dx / distance, dy / distance) if distance else (1, 0)
            for _ in range(stats["count"]):
                self.sparks.append(Spark(self.x, self.y, vx * c["spark"]["speed"],
                                         vy * c["spark"]["speed"], c["spark"]["lifetime"], stats["damage"]))
            self.spark_clock = stats["interval"]

        remaining = []
        for spark in self.sparks:
            spark.x += spark.vx * dt
            spark.y += spark.vy * dt
            spark.lifetime -= dt
            hit = next((b for b in self.enemies if b.hp > 0 and
                        math.hypot(b.x - spark.x, b.y - spark.y) <=
                        self.enemy_radius(b) + c["spark"]["radius"]), None)
            if hit is not None:
                self._damage(hit, spark.damage)
            elif spark.lifetime > 0:
                remaining.append(spark)
        self.sparks = remaining

        if self.weapons.get("blades"):
            damage = self.weapon_stats("blades")["damage"]
            for i, (bx, by) in enumerate(self.blade_positions()):
                for bat in self.enemies:
                    if bat.blade_cooldowns.get(i, 0) <= 1e-9 and math.hypot(bat.x - bx, bat.y - by) <= c["blades"]["radius"] + self.enemy_radius(bat):
                        self._damage(bat, damage)
                        bat.blade_cooldowns[i] = c["blades"]["hit_interval"]

        if self.weapons.get("ring"):
            self.ring_clock = max(0, self.ring_clock - dt)
            if self.ring_clock <= 1e-9:
                stats = self.weapon_stats("ring")
                for bat in self.enemies:
                    if math.hypot(bat.x - self.x, bat.y - self.y) <= stats["radius"]:
                        self._damage(bat, stats["damage"])
                self.ring_clock = c["ring"]["interval"]
        self.enemies = [b for b in self.enemies if b.hp > 0]

        for bat in self.enemies:
            if bat.hit_cooldown <= 1e-9 and math.hypot(bat.x - self.x, bat.y - self.y) <= c["hero"]["radius"] + self.enemy_radius(bat):
                previous_hp = self.hp
                self.hp = max(0, self.hp - c[bat.kind]["damage"])
                if self.hp < previous_hp:
                    self.events.append(GameEvent("hurt", self.x, self.y, previous_hp - self.hp))
                bat.hit_cooldown = c["contact_interval"]
        self.game_over = self.hp <= 0
        if self.game_over:
            self.events.append(GameEvent("game_over", self.x, self.y))
            return
        remaining_gems = []
        collected_xp = 0
        for gem in self.gems:
            dx, dy = self.x - gem.x, self.y - gem.y
            distance = math.hypot(dx, dy)
            if distance <= self.magnet_radius:
                gem.attracted = True
            if gem.attracted:
                travel = min(distance, c["gems"]["speed"] * dt)
                if distance:
                    gem.x += dx / distance * travel
                    gem.y += dy / distance * travel
                distance -= travel
            if distance <= c["hero"]["radius"]:
                collected_xp += gem.xp
                self.events.append(GameEvent("gem", gem.x, gem.y, gem.xp))
            else:
                remaining_gems.append(gem)
        self.gems = remaining_gems
        self.award_xp(collected_xp)
