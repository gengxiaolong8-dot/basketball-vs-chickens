# Custom game audio

- chicken_background.wav: user-provided chicken recording; loops during play.
- hit_custom.wav: user-provided Version B, 0.2-second hit sound; plays on enemy damage.
- game_over_custom.wav: user-provided failure voice clip; plays once on game over.
- victory_custom.wav: user-provided victory voice clip; plays once on victory.

Background music pauses with P and upgrade cards, stops on either end screen,
and starts from the beginning on a new run. Per-sound volume and filenames are
configured in data/game.json under audio.

The original hurt, gem and level-up effects remain in use. make_sounds.py only
regenerates the original filenames, so it preserves these custom recordings.
The custom files are separate copies; original user recordings are unchanged.
