"""Run with py -3.14 main.py. Loads finished art from assets/."""

import asyncio
import math
from pathlib import Path
import random
import pygame

from rules import Game, load_config


class Feedback:
    """Short-lived pictures and audio; these never change the game rules."""

    CHANNELS = {"hit": 0, "gem": 1, "hurt": 2, "level_up": 3, "victory": 4, "game_over": 4}

    def __init__(self, config, pictures):
        self.config = config
        self.settings = config["feel"]
        self.font = pygame.font.Font(None, self.settings["number_font_size"])
        self.flash_pictures = {}
        for kind in {kind for wave in config["waves"] for kind in wave["types"]} | {config["boss"]["kind"]}:
            image = pictures[kind].copy()
            image.fill((255, 255, 255), special_flags=pygame.BLEND_RGB_ADD)
            self.flash_pictures[kind] = image
        self.sounds = {}
        self.music_ready = False
        self.music_state = "stopped"
        self.audio_attempted = False
        self.rng = random.Random()
        self.clear()
        if pygame.mixer.get_init():
            self.enable_audio()

    def enable_audio(self):
        # A user gesture can initialise audio if it was unavailable at startup.
        if self.audio_attempted:
            return
        self.audio_attempted = True
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=self.config["audio"]["sample_rate"])
            pygame.mixer.set_num_channels(max(self.CHANNELS.values()) + 1)
            folder = Path(__file__).resolve().parent / "sounds"
            for name in self.config["audio"]["sounds"]:
                stem = self.config["audio"].get("files", {}).get(name, name)
                path = self.audio_path(folder, stem)
                if path is not None:
                    sound = pygame.mixer.Sound(str(path))
                    sound.set_volume(self.config["audio"].get("volumes", {}).get(name, self.config["audio"]["volume"]))
                    self.sounds[name] = sound
        except pygame.error as error:
            self.sounds.clear()
            print(f"Audio unavailable; playing silently: {error}")
            return
        background = self.config["audio"].get("background")
        if background:
            path = self.audio_path(folder, background["file"])
            if path is not None:
                try:
                    pygame.mixer.music.load(str(path))
                    pygame.mixer.music.set_volume(background["volume"])
                    self.music_ready = True
                except pygame.error as error:
                    print(f"Background music unavailable: {error}")

    @staticmethod
    def audio_path(folder, stem):
        return next((folder / f"{stem}{suffix}" for suffix in (".ogg", ".wav")
                     if (folder / f"{stem}{suffix}").is_file()), None)

    def sync_music(self, paused, finished):
        """Loop during play, pause with the game, stop at either end screen."""
        if not self.music_ready:
            return
        if finished:
            if self.music_state != "ended":
                pygame.mixer.music.stop()
                self.music_state = "ended"
            return
        if self.music_state in ("stopped", "ended"):
            pygame.mixer.music.play(loops=-1)
            self.music_state = "playing"
        if paused and self.music_state == "playing":
            pygame.mixer.music.pause()
            self.music_state = "paused"
        elif not paused and self.music_state == "paused":
            pygame.mixer.music.unpause()
            self.music_state = "playing"

    def clear(self):
        self.numbers = []
        self.flashes = []
        self.shake_time = 0.0
        self.offset = (0, 0)
        self.sound_cooldowns = {}
        self.music_state = "stopped"
        if pygame.mixer.get_init():
            pygame.mixer.stop()
            pygame.mixer.music.stop()

    def update(self, dt, animate=True):
        self.sound_cooldowns = {name: remaining - dt for name, remaining in self.sound_cooldowns.items() if remaining > dt}
        if not animate:
            return
        for number in self.numbers:
            number[3] -= dt
            number[2] -= self.settings["number_rise_speed"] * dt
        self.numbers = [number for number in self.numbers if number[3] > 0]
        for flash in self.flashes:
            flash[3] -= dt
        self.flashes = [flash for flash in self.flashes if flash[3] > 0]
        self.shake_time = max(0, self.shake_time - dt)
        self._shake_offset()

    def _shake_offset(self):
        strength = self.settings["shake_pixels"] * self.shake_time / self.settings["shake_lifetime"]
        self.offset = (round(self.rng.uniform(-strength, strength)), round(self.rng.uniform(-strength, strength))) if self.shake_time > 0 else (0, 0)

    def consume(self, events):
        cues = set()
        for event in events:
            cues.add(event.kind)
            if event.kind in ("hit", "hurt"):
                color = (255, 235, 145) if event.kind == "hit" else (255, 90, 110)
                text = f'{event.amount:g}' if event.kind == "hit" else f'-{event.amount:g}'
                self.numbers.append([text, event.x, event.y, self.settings["number_lifetime"], color])
            if event.kind == "death":
                self.flashes.append([event.enemy_kind, event.x, event.y, self.settings["flash_lifetime"]])
            elif event.kind == "hurt" or (event.kind == "hit" and
                    event.enemy_kind == self.config["boss"]["kind"] and event.amount > 0):
                # Every boss damage event refreshes the shake, with no hit cooldown.
                self.shake_time = self.settings["shake_lifetime"]
                self._shake_offset()
        for name in self.CHANNELS:
            if name in cues and name in self.sounds and self.sound_cooldowns.get(name, 0) <= 0:
                # Separate channels keep a gem or hit from cutting off the end tune.
                pygame.mixer.Channel(self.CHANNELS[name]).play(self.sounds[name])
                self.sound_cooldowns[name] = self.config["audio"]["cue_cooldown"]

    def draw_flashes(self, screen, left, top):
        for kind, x, y, remaining in self.flashes:
            image = self.flash_pictures[kind]
            image.set_alpha(round(255 * remaining / self.settings["flash_lifetime"]))
            screen.blit(image, image.get_rect(center=(round(x - left), round(y - top))))

    def draw_numbers(self, screen, left, top):
        for text, x, y, remaining, color in self.numbers:
            alpha = round(255 * remaining / self.settings["number_lifetime"])
            image = self.font.render(text, True, color)
            shadow = self.font.render(text, True, (18, 21, 30))
            image.set_alpha(alpha)
            shadow.set_alpha(alpha)
            rect = image.get_rect(midbottom=(round(x - left), round(y - top)))
            screen.blit(shadow, rect.move(1, 1))
            screen.blit(image, rect)


def card_rects(width, height, count):
    return [pygame.Rect(24, height // 4 + i * 118, width - 48, 104)
            for i in range(count)]


def time_text(seconds):
    seconds = int(seconds + 1e-9)
    return f'{seconds // 60}:{seconds % 60:02d}'


async def main():
    config = load_config()
    pygame.mixer.pre_init(frequency=config["audio"]["sample_rate"])
    pygame.init()
    width, height = config["screen"]["width"], config["screen"]["height"]
    screen = pygame.display.set_mode((width, height))
    labels = config["labels"]
    pygame.display.set_caption(labels["title"])
    asset_dir = Path(__file__).resolve().parent / "assets"
    pictures = {name: pygame.image.load(str(asset_dir / f"{name}.png")).convert_alpha()
                for name in ("hero", "floor", "bat", "slime", "ghost", "demon", "sword")}
    gem_pictures = {xp: pygame.image.load(str(asset_dir / f"gem_{color}.png")).convert_alpha()
                    for color, xp in config["art"]["gem_xp_values"].items()}
    # The boss chicken is twice the regular copy. scale keeps hard pixel edges.
    for kind in {kind for wave in config["waves"] for kind in wave["types"]} | {config["boss"]["kind"]}:
        scale = config[kind].get("size_scale", 1)
        if scale != 1:
            image = pictures[kind]
            pictures[kind] = pygame.transform.scale(image, (round(image.get_width() * scale), round(image.get_height() * scale)))
    feedback = Feedback(config, pictures)
    font = pygame.font.Font(None, 24)
    large = pygame.font.Font(None, 48)
    clock = pygame.time.Clock()
    game = Game(config)
    pointer = (width / 2, height / 2)
    finger = None
    touch_mode = False
    paused = False
    accumulator = 0.0
    running = True
    pause_button = pygame.Rect(width - 56, 8, 44, 40)

    def toggle_pause():
        nonlocal paused, accumulator
        paused = not paused
        accumulator = 0.0

    def select_card(position):
        nonlocal pointer, finger, accumulator
        for index, rect in enumerate(card_rects(width, height, len(game.cards))):
            if rect.collidepoint(position):
                game.choose_card(index)
                pointer = (width / 2, height / 2)
                finger = None
                accumulator = 0.0
                break

    def label(text, position, color=(235, 240, 250), big=False, centered=False):
        surface = (large if big else font).render(text, True, color)
        rect = surface.get_rect(center=position) if centered else surface.get_rect(topleft=position)
        screen.blit(surface, rect)

    while running:
        frame_dt = min(clock.tick(config["screen"]["fps"]) / 1000, 0.25)
        for event in pygame.event.get():
            if event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN, pygame.KEYDOWN):
                feedback.enable_audio()
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_p:
                if not game.finished and not game.cards:
                    toggle_pause()
            elif event.type in (pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN):
                # Touch creates synthetic mouse events on some platforms.
                if not getattr(event, "touch", False):
                    if pause_button.collidepoint(event.pos) and not game.finished and not game.cards:
                        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                            pointer = (width / 2, height / 2)
                            finger = None
                            toggle_pause()
                        # Clicking or hovering the button must not steer the hero.
                        continue
                    touch_mode = False
                    pointer = event.pos
                    if event.type == pygame.MOUSEBUTTONDOWN and game.finished:
                        game = Game(config)
                        feedback.clear()
                        paused = False
                        accumulator = 0.0
                    elif event.type == pygame.MOUSEBUTTONDOWN and game.cards and not paused:
                        select_card(event.pos)
            elif event.type == pygame.FINGERDOWN:
                position = (event.x * width, event.y * height)
                if pause_button.collidepoint(position) and not game.finished and not game.cards:
                    touch_mode = True
                    pointer = (width / 2, height / 2)
                    finger = None
                    toggle_pause()
                    continue
                touch_mode = True
                finger = event.finger_id
                pointer = (event.x * width, event.y * height)
                if game.finished:
                    game = Game(config)
                    feedback.clear()
                    paused = False
                    accumulator = 0.0
                elif game.cards and not paused:
                    select_card(pointer)
            elif event.type == pygame.FINGERMOTION and event.finger_id == finger:
                pointer = (event.x * width, event.y * height)
            elif event.type == pygame.FINGERUP and event.finger_id == finger:
                finger = None

        feedback.update(frame_dt, animate=not paused and not game.cards)
        if not paused and not game.finished and not game.cards:
            accumulator += frame_dt
            while accumulator >= config["fixed_dt"]:
                target = None if touch_mode and finger is None else (
                    game.x + pointer[0] - width / 2,
                    game.y + pointer[1] - height / 2)
                game.step(target)
                accumulator -= config["fixed_dt"]
                if game.cards or game.finished:
                    accumulator = 0.0
                    break
        else:
            accumulator = 0.0
        feedback.consume(game.pop_events())
        feedback.sync_music(paused=paused or bool(game.cards), finished=game.finished)

        # The hero stays in the centre. World objects scroll past the camera.
        tile_w, tile_h = pictures["floor"].get_size()
        shake_x, shake_y = feedback.offset
        hero_pos = (width // 2 + shake_x, height // 2 + shake_y)
        left, top = game.x - width / 2 - shake_x, game.y - height / 2 - shake_y
        first_x, first_y = math.floor(left / tile_w), math.floor(top / tile_h)
        screen.fill((18, 25, 35))
        for tx in range(first_x, first_x + math.ceil(width / tile_w) + 1):
            for ty in range(first_y, first_y + math.ceil(height / tile_h) + 1):
                screen.blit(pictures["floor"], (round(tx * tile_w - left), round(ty * tile_h - top)))
        if game.weapons.get("ring"):
            pygame.draw.circle(screen, (112, 119, 226), hero_pos, game.weapon_stats("ring")["radius"], 2)
        for gem in game.gems:
            gx, gy = round(gem.x - left), round(gem.y - top)
            image = gem_pictures[gem.xp]
            screen.blit(image, image.get_rect(center=(gx, gy)))
        for enemy in game.enemies:
            pos = (round(enemy.x - left), round(enemy.y - top))
            r = game.enemy_radius(enemy)
            px, py = pos
            image = pictures[enemy.kind]
            sprite_rect = image.get_rect(center=pos)
            screen.blit(image, sprite_rect)
            if enemy.kind == config["boss"]["kind"]:
                bar = pygame.Rect(px - r, sprite_rect.bottom + 4, r * 2, 5)
                pygame.draw.rect(screen, (75, 30, 40), bar)
                pygame.draw.rect(screen, (255, 101, 114), (bar.x, bar.y, round(bar.width * enemy.hp / config[enemy.kind]["hp"]), bar.height))
                label(labels["enemies"][enemy.kind], (px, sprite_rect.top - 12), centered=True)
        feedback.draw_flashes(screen, left, top)
        for spark in game.sparks:
            pos = (round(spark.x - left), round(spark.y - top))
            radius = config["spark"]["radius"]
            pygame.draw.circle(screen, (244, 137, 43), pos, radius)
            pygame.draw.circle(screen, (71, 45, 35), pos, radius, 1)
            pygame.draw.line(screen, (71, 45, 35), (pos[0], pos[1] - radius), (pos[0], pos[1] + radius))
        for bx, by in game.blade_positions():
            px, py = round(bx - left), round(by - top)
            image = pictures["sword"]
            screen.blit(image, image.get_rect(center=(px, py)))
        image = pictures["hero"]
        screen.blit(image, image.get_rect(center=hero_pos))
        feedback.draw_numbers(screen, left, top)

        pygame.draw.rect(screen, (12, 18, 28), (0, 0, width, 94))
        bar_width = width - 136
        pygame.draw.rect(screen, (76, 35, 48), (16, 12, bar_width, 14))
        pygame.draw.rect(screen, (229, 74, 94), (16, 12, round(bar_width * game.hp / game.max_hp), 14))
        pygame.draw.rect(screen, (25, 49, 85), (16, 32, bar_width, 10))
        pygame.draw.rect(screen, (70, 153, 248), (16, 32, round(bar_width * min(1, game.xp / game.xp_needed)), 10))
        label(f'HP {game.hp}/{game.max_hp}   XP {game.xp}/{game.xp_needed}', (16, 48))
        label(f'Lv {game.level}', (16, 70))
        label(labels["title"], (100, 70))
        label(f'{time_text(game.elapsed)} / {time_text(config["survival_seconds"])}', (width - 116, 54))
        label(f'{labels["kills"]} {game.kills}', (width - 102, 76))
        pygame.draw.rect(screen, (12, 18, 28), (0, height - 90, width, 90))
        short_names = labels["short_names"]
        weapons = "   ".join(f'{short_names[name]} {level}' for name, level in game.weapons.items())
        items = "   ".join(f'{short_names[name]} {level}' for name, level in game.passives.items() if level)
        label(weapons, (16, height - 80))
        label(items or labels["collect_hint"], (16, height - 55), (156, 172, 195))
        label(labels["controls_hint"], (16, height - 28), (156, 172, 195))
        if paused or game.finished or game.cards:
            overlay = pygame.Surface((width, height), pygame.SRCALPHA)
            overlay.fill((5, 9, 18, 220))
            screen.blit(overlay, (0, 0))
            if game.cards and not game.finished:
                label(labels["level_up"], (width / 2, 110), big=True, centered=True)
                label(f'Level {game.level} - choose one upgrade', (width / 2, 147), centered=True)
                for choice, rect in zip(game.cards, card_rects(width, height, len(game.cards))):
                    pygame.draw.rect(screen, (35, 54, 78), rect, border_radius=12)
                    pygame.draw.rect(screen, (90, 174, 225), rect, 2, border_radius=12)
                    title, description = game.card_details(choice)
                    label(title, (rect.x + 16, rect.y + 22))
                    label(description, (rect.x + 16, rect.y + 58), (174, 205, 225))
                label("Click or tap a card", (width / 2, height - 110), centered=True)
            elif game.finished:
                label(labels["victory"] if game.victory else labels["game_over"], (width / 2, height / 2 - 55), big=True, centered=True)
                label(f'Time {time_text(game.elapsed)}   {labels["kills"]} {game.kills}', (width / 2, height / 2), centered=True)
                label(f'Level {game.level}', (width / 2, height / 2 + 25), centered=True)
                label("Click or tap to play again", (width / 2, height / 2 + 45), centered=True)
            else:
                label("PAUSED", (width / 2, height / 2 - 55), big=True, centered=True)
                label("Click play or press P to resume", (width / 2, height / 2 + 15), centered=True)
        # Keep the resume button visible and clickable above the pause overlay.
        if not game.finished and not game.cards:
            pygame.draw.rect(screen, (39, 80, 105), pause_button, border_radius=8)
            pygame.draw.rect(screen, (104, 193, 218), pause_button, 2, border_radius=8)
            if paused:
                pygame.draw.polygon(screen, (237, 250, 255), [(pause_button.x + 17, pause_button.y + 11),
                                         (pause_button.x + 17, pause_button.y + 29),
                                         (pause_button.x + 31, pause_button.y + 20)])
            else:
                for dx in (14, 25):
                    pygame.draw.rect(screen, (237, 250, 255), (pause_button.x + dx, pause_button.y + 11, 5, 18))
        pygame.display.flip()
        await asyncio.sleep(0)
    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
