# Basketball vs Chickens — design (CDT501 Lecture 9)

A tiny game in the "survivors" style: you roll a basketball, your basketball powers attack by themselves,
chickens attack from every side, you grow stronger every level. The basketball must escape the flock. Names and all on-screen text are in English.
The original Kenney art in raw_art/ stays unchanged; themed copies live in assets/.

## Goal
- Survive until **2:00**: then the game shows VICTORY.
- Basketball HP reaches 0: BALL POPPED.
- Click or tap the end screen to play again.

## Screen and controls
- Window 390 x 700 (portrait, like a phone). The camera follows the basketball.
- The floor is one tile repeated forever: the map has no edges.
- Computer: the basketball rolls toward the mouse pointer and keeps rolling as long as the pointer
  is more than 12 px away from it, even when the mouse does not move.
- Phone: the basketball rolls toward the finger while it touches the screen and stops when it is lifted.
- Click or tap a card to choose it. P pauses.
- Click or tap the top-right pause button to pause; its play icon resumes the game.

## Basketball
| Speed | HP | Hit radius | Gem magnet radius |
|---|---|---|---|
| 120 px/s | 100 | 12 px | 60 px |

## Basketball powers (start with Bounce Shot; at most 3 powers; levels 1–5)
| Power | What it does | Level 1 | Each extra level |
|---|---|---|---|
| Bounce Shot | shoots a small basketball (speed 400 px/s) at the nearest chicken | 20 damage, every 0.8 s, 1 shot | +3 damage, 0.08 s faster; +1 shot at levels 3 and 5 |
| Orbit Balls | basketballs circle the basketball at 60 px, one turn every 1.5 s; each orbit ball hits a chicken at most every 0.5 s | 2 orbit balls, 8 damage | +3 damage; +1 orbit ball at levels 2 and 4 |
| Court Ring | hurts every chicken inside a circle around the basketball, every 0.5 s | 5 damage, radius 50 px | +2 damage, +10 px radius |

## Passive items (levels 1–5)
| Item | Each level |
|---|---|
| Grip Wrap | +10% rolling speed |
| Extra Air | +20 max HP and heal 20 |
| Court Magnet | +30 px gem magnet radius |

## Chickens
| Chicken | HP | Speed | Damage | XP | Picture |
|---|---|---|---|---|---|
| Chick | 8 | 100 | 5 | 1 | bat.png |
| Hen | 30 | 55 | 8 | 2 | slime.png |
| Rooster | 15 | 135 (faster than you) | 6 | 2 | ghost.png |
| Boss: King Rooster | 800 | 85 | 20 | 0 | demon.png, drawn twice as big |

A chicken that touches the basketball pecks it at most once every 0.5 s.

## How chickens appear (the map is endless, so chickens come to you)
- Every 1 s: if fewer chickens are alive than the **minimum** for this time, spawn new ones
  (at most 8 per second) until the minimum is reached.
- New chickens appear at a random point on a circle 380 px from the basketball, just outside the screen.
- Any normal chicken more than 700 px from the basketball is removed. New ones will come.
- The boss is never removed: if it is more than 600 px away, move it back to the 380 px circle.
- Never more than 120 chickens alive.

| From | Chicken types | Minimum alive |
|---|---|---|
| 0:00 | Chick | 12 |
| 0:15 | Chick | 20 |
| 0:30 | Chick, Hen | 28 |
| 0:45 | Hen, Rooster | 36 |
| 1:00 | Chick, Rooster | 45 |
| 1:15 | Chick, Hen, Rooster | 55 |
| 1:30 | the boss appears once; Chick, Hen | 55 |
| 1:45 | Chick | 75 |

## XP and level-up
- Every defeated chicken drops a gem worth its XP. Gems inside the magnet radius fly to the basketball (300 px/s).
- XP needed for the next level: 5 at level 1, then 3 more each level (5, 8, 11, 14, ...).
- Level-up: the game pauses and shows 3 random cards. A card is a new basketball power (if fewer than 3),
  +1 level for a power you have, or a passive item. Never offer something already at level 5.
  If nothing is left, offer "Pump Up: Heal 30 HP".

## What the screen shows
- Top left: HP bar (red), XP bar (blue) and "Lv 3".
- Top right: the timer, for example "0:45 / 2:00".
- Bottom: what you have, for example "Shot 2  Orbit 1  Grip 1".
- Level-up: 3 big cards, each with a name, the new level and one line of text.
- End: VICTORY or BALL POPPED, with time, chickens cleared and level.

## Build steps (build one step at a time, only when asked)
1. **Core:** basketball and controls, camera and repeating floor, Chicks with the spawning rules,
   contact damage, Bounce Shot, HP, BALL POPPED and play again. Coloured shapes, no pictures yet.
2. **Pictures:** make_assets.py tints the original art with Pillow, adds basketball seams and chicken details,
   and makes 3x bigger finished pictures (no blurring),
   plus two bright crystal gems coloured from raw_art/gem.png: blue for XP 1, pink for XP 2.
   main.py draws them.
3. **Growth:** gems, XP, level-up cards, all powers and passive items.
4. **Waves:** the whole table above, Hen, Rooster, the boss, VICTORY at 2:00, the timer.
5. **Sound and feel:** make_sounds.py (standard library only) makes short sounds for hits,
   gems, level-up, getting hurt and the end; damage numbers, a flash when a chicken dies,
   a small shake when the basketball is hurt.

## Custom audio
- Chicken background recording loops during play; it pauses with P and upgrade cards.
- The background stops on either end screen and restarts from the beginning for a new run.
- Enemy hits use the user-provided 0.2-second Version B sound.
- Failure and victory each play their user-provided voice clip once.
- Hurt, gem and level-up use soft generated tones. Custom filenames and volume live in data/game.json.
- make_sounds.py preserves the separately named custom recordings.
- Audio mixes at 44100 Hz with a 2048-sample buffer. All effect clips finish before replaying; the gem cue uses a softer, lower tone.
- At either end screen, gameplay audio fades out over 40 ms before the custom voice plays alone.
