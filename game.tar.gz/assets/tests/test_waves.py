import math
import random
import unittest

from rules import Enemy, Game, load_config


class WaveTests(unittest.TestCase):
    def setUp(self):
        self.c = load_config()
        self.game = Game(self.c, random.Random(42))

    def test_every_wave_boundary_and_spawn_mix(self):
        dt = self.c["fixed_dt"]
        for index, wave in enumerate(self.c["waves"]):
            with self.subTest(start=wave["from"]):
                if index:
                    self.game.elapsed = wave["from"] - dt
                    self.assertEqual(self.game.current_wave(), self.c["waves"][index - 1])
                self.game.elapsed = wave["from"]
                self.assertEqual(self.game.current_wave(), wave)
                self.game.enemies = []
                self.game.spawn_enemies()
                self.assertEqual(len(self.game.enemies), min(wave["minimum_alive"], self.c["spawning"]["max_per_second"]))
                for enemy in self.game.enemies:
                    self.assertIn(enemy.kind, wave["types"])
                    self.assertEqual(enemy.hp, self.c[enemy.kind]["hp"])
                    self.assertAlmostEqual(math.hypot(enemy.x, enemy.y), self.c["spawning"]["radius"])
                for _ in range(self.c["spawning"]["max_alive"]):
                    self.game.spawn_enemies()
                self.assertEqual(len(self.game.enemies), min(wave["minimum_alive"], self.c["spawning"]["max_alive"]))

    def test_each_enemy_uses_its_own_speed_damage_and_xp(self):
        for kind in {kind for wave in self.c["waves"] for kind in wave["types"]} | {self.c["boss"]["kind"]}:
            with self.subTest(kind=kind):
                game = Game(load_config(), random.Random(9))
                game.spark_clock = 100
                enemy = Enemy(100, 0, self.c[kind]["hp"], kind=kind)
                game.enemies = [enemy]
                game.step()
                self.assertAlmostEqual(enemy.x, 100 - self.c[kind]["speed"] * self.c["fixed_dt"])
                enemy.x, enemy.y = game.x, game.y
                game.step()
                self.assertEqual(game.hp, self.c["hero"]["hp"] - self.c[kind]["damage"])
                # Let Spark kill this enemy away from gem pickup range.
                enemy.x = game.x + 100
                enemy.hp = self.c["spark"]["damage"]
                game.spark_clock = 0
                for _ in range(round(0.3 / self.c["fixed_dt"])):
                    game.step()
                self.assertEqual(game.kills, 1)
                self.assertEqual(sum(gem.xp for gem in game.gems) + game.xp, self.c[kind]["xp"])

    def test_normal_enemy_removal_and_boss_return_preserve_hp(self):
        boss_kind = self.c["boss"]["kind"]
        boss = Enemy(self.c["spawning"]["remove_distance"] + 100, 0, self.c[boss_kind]["hp"] / 2, kind=boss_kind)
        normal = Enemy(self.c["spawning"]["remove_distance"] + 1, 0, self.c["bat"]["hp"])
        self.game.enemies = [normal, boss]
        self.game.step()
        self.assertNotIn(normal, self.game.enemies)
        self.assertIn(boss, self.game.enemies)
        self.assertEqual(boss.hp, self.c[boss_kind]["hp"] / 2)
        self.assertAlmostEqual(math.hypot(boss.x, boss.y), self.c["spawning"]["radius"] - self.c[boss_kind]["speed"] * self.c["fixed_dt"])

    def test_boss_appears_once_on_time_even_at_enemy_cap(self):
        dt = self.c["fixed_dt"]
        start = self.c["boss"]["spawn_time"]
        self.game.elapsed = start - 2 * dt
        self.game.spark_clock = 100
        self.game.step()
        self.assertFalse(self.game.boss_spawned)
        cap = self.c["spawning"]["max_alive"]
        self.game.enemies = [Enemy(300, 0, self.c["bat"]["hp"]) for _ in range(cap)]
        self.game.step()
        self.assertTrue(self.game.boss_spawned)
        kind = self.c["boss"]["kind"]
        bosses = [enemy for enemy in self.game.enemies if enemy.kind == kind]
        self.assertEqual(len(bosses), 1)
        self.assertEqual(bosses[0].hp, self.c[kind]["hp"])
        self.assertLessEqual(len(self.game.enemies), cap)
        # A dead boss must not respawn on the next tick.
        self.game._damage(bosses[0], bosses[0].hp)
        self.game.step()
        self.assertFalse(any(enemy.kind == kind for enemy in self.game.enemies))
        self.assertTrue(self.game.boss_spawned)

    def test_victory_at_survival_time_freezes_and_restart_resets(self):
        dt = self.c["fixed_dt"]
        self.game.elapsed = self.c["survival_seconds"] - 2 * dt
        self.game.step()
        self.assertFalse(self.game.finished)
        self.game.step()
        self.assertTrue(self.game.victory)
        self.assertFalse(self.game.game_over)
        self.assertEqual(self.game.elapsed, self.c["survival_seconds"])
        x, hp = self.game.x, self.game.hp
        self.game.step((10000, 0))
        self.assertEqual((self.game.elapsed, self.game.x, self.game.hp), (self.c["survival_seconds"], x, hp))
        fresh = Game(self.c)
        self.assertFalse(fresh.finished)
        self.assertFalse(fresh.boss_spawned)
        self.assertEqual(fresh.elapsed, 0)
        self.assertEqual(fresh.enemies, [])

    def test_zero_hp_loses_instead_of_winning(self):
        self.game.elapsed = self.c["survival_seconds"] - self.c["fixed_dt"]
        self.game.hp = 0
        self.game.step()
        self.assertTrue(self.game.game_over)
        self.assertFalse(self.game.victory)

    def test_changing_config_changes_waves_boss_and_goal(self):
        self.c["waves"] = [{"from": 0, "types": ["ghost"], "minimum_alive": 4}]
        self.c["boss"]["spawn_time"] = self.c["fixed_dt"]
        self.c["survival_seconds"] = self.c["fixed_dt"] * 3
        self.c["spawning"]["interval"] = self.c["fixed_dt"]
        self.c["spawning"]["max_alive"] = 3
        self.game.step()
        self.assertTrue(self.game.boss_spawned)
        self.assertEqual(len(self.game.enemies), 3)
        self.assertEqual(sum(enemy.kind == "ghost" for enemy in self.game.enemies), 2)
        self.game.step()
        self.assertFalse(self.game.finished)
        self.game.step()
        self.assertTrue(self.game.victory)


if __name__ == "__main__":
    unittest.main()
