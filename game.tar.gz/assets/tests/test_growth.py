import math
import random
import unittest

from rules import Enemy, Game, Gem, load_config


class GrowthTests(unittest.TestCase):
    def setUp(self):
        self.c = load_config()
        self.game = Game(self.c, random.Random(12))

    def advance(self, seconds):
        for _ in range(round(seconds / self.c["fixed_dt"])):
            self.game.step()

    def test_kill_drops_one_gem_with_enemy_xp(self):
        self.game.enemies = [Enemy(70, 0, self.c["bat"]["hp"])]
        self.advance(0.2)
        self.assertEqual(self.game.kills, 1)
        self.assertEqual(len(self.game.gems), 1)
        self.assertEqual(self.game.gems[0].xp, self.c["bat"]["xp"])
        self.assertEqual(self.game.xp, 0)

    def test_magnet_moves_gems_at_configured_speed_and_collects(self):
        near = Gem(self.game.magnet_radius, 0, self.c["bat"]["xp"])
        far = Gem(self.game.magnet_radius + 10, 0, self.c["bat"]["xp"])
        self.game.gems = [near, far]
        start = near.x
        self.game.step()
        self.assertAlmostEqual(start - near.x, self.c["gems"]["speed"] * self.c["fixed_dt"])
        self.assertEqual(far.x, self.game.magnet_radius + 10)
        # Once attracted, a gem keeps flying even if the hero moves away.
        self.game.x = -self.game.magnet_radius
        self.game.step()
        self.assertLess(near.x, start - self.c["gems"]["speed"] * self.c["fixed_dt"])
        self.advance(0.6)
        self.assertEqual(self.game.xp, near.xp)
        self.assertEqual(self.game.gems, [far])

    def test_xp_threshold_pause_and_overflow(self):
        first = self.c["growth"]["xp_first"]
        second = first + self.c["growth"]["xp_increase"]
        self.game.award_xp(first + second)
        self.assertEqual(self.game.level, 2)
        self.assertEqual(self.game.xp, second)
        self.assertEqual(self.game.xp_needed, second)
        self.assertEqual(len(self.game.cards), self.c["growth"]["card_count"])
        before = self.game.elapsed
        self.game.step((1000, 0))
        self.assertEqual(self.game.elapsed, before)
        self.assertEqual(self.game.x, 0)
        self.assertFalse(self.game.choose_card(-1))
        self.game.choose_card(0)
        self.assertEqual(self.game.level, 3)
        self.assertEqual(self.game.xp, 0)
        self.assertTrue(self.game.cards)
        self.game.choose_card(0)
        self.game.step()
        self.assertGreater(self.game.elapsed, before)

    def test_card_caps_and_heal_fallback(self):
        cap = self.c["growth"]["max_level"]
        self.game.weapons = {"spark": cap}
        self.game.config["growth"]["max_weapons"] = 1
        self.game.award_xp(self.game.xp_needed)
        self.assertTrue(all(card in self.game.passives for card in self.game.cards))
        self.game.choose_card(0)
        # Exhaust every upgrade through actual card selections.
        for _ in range(100):
            self.game.award_xp(self.game.xp_needed)
            for card in self.game.cards:
                if card != "heal":
                    self.assertLess(self.game.weapons.get(card, self.game.passives.get(card, 0)), cap)
            if self.game.cards[0] == "heal":
                break
            self.game.choose_card(0)
        self.assertEqual(self.game.cards, ["heal"] * self.c["growth"]["card_count"])
        self.game.hp = 1
        self.game.choose_card(0)
        self.assertEqual(self.game.hp, min(self.game.max_hp, 1 + self.c["growth"]["fallback_heal"]))
        self.assertEqual(len(self.game.weapons), 1)

    def test_passives_change_movement_health_and_pickup(self):
        self.game.hp -= self.c["passives"]["heart_heal_per_level"]
        for name in ("boots", "heart", "magnet"):
            self.game.cards = [name]
            self.game.choose_card(0)
        self.assertEqual(self.game.max_hp, self.c["hero"]["hp"] + self.c["passives"]["heart_hp_per_level"])
        self.assertEqual(self.game.hp, self.c["hero"]["hp"])
        self.game.step((1000, 0))
        expected_speed = self.c["hero"]["speed"] * (1 + self.c["passives"]["boots_speed_per_level"])
        self.assertAlmostEqual(self.game.x, expected_speed * self.c["fixed_dt"])
        self.assertEqual(self.game.magnet_radius, self.c["hero"]["magnet_radius"] + self.c["passives"]["magnet_radius_per_level"])
        gem = Gem(self.game.x + self.game.magnet_radius, 0, self.c["bat"]["xp"])
        self.game.gems.append(gem)
        self.game.step()
        self.assertTrue(gem.attracted)

    def test_spark_upgrade_count_damage_and_interval(self):
        level = self.c["growth"]["max_level"]
        self.game.weapons["spark"] = level
        self.game.enemies = [Enemy(200, 0, 10000)]
        self.game.step()
        count = self.c["spark"]["count"] + len(self.c["spark"]["extra_spark_levels"])
        self.assertEqual(len(self.game.sparks), count)
        damage = self.c["spark"]["damage"] + (level - 1) * self.c["spark"]["damage_per_level"]
        self.assertTrue(all(s.damage == damage for s in self.game.sparks))
        interval = self.c["spark"]["interval"] - (level - 1) * self.c["spark"]["interval_per_level"]
        self.assertAlmostEqual(self.game.spark_clock, interval)
        # Separate targets stay alive to check the next volley time.
        for _ in range(math.ceil(interval / self.c["fixed_dt"]) - 1):
            self.game.step()
        self.assertLess(self.game.spark_clock, interval)
        self.game.step()
        self.assertAlmostEqual(self.game.spark_clock, interval)

    def test_ring_hits_every_enemy_inside_only_each_interval(self):
        self.game.weapons["ring"] = 1
        self.game.spark_clock = 100
        radius = self.c["ring"]["radius"]
        # Keep enemies still to isolate range and repeat timing.
        self.c["bat"]["speed"] = 0
        inside = [Enemy(radius, 0, 1000), Enemy(0, radius, 1000)]
        outside = Enemy(radius + 1, 0, 1000)
        self.game.enemies = inside + [outside]
        self.game.step()
        damage = self.c["ring"]["damage"]
        self.assertTrue(all(b.hp == 1000 - damage for b in inside))
        self.assertEqual(outside.hp, 1000)
        ticks = round(self.c["ring"]["interval"] / self.c["fixed_dt"])
        for _ in range(ticks - 1):
            self.game.step()
        self.assertEqual(inside[0].hp, 1000 - damage)
        self.game.step()
        self.assertEqual(inside[0].hp, 1000 - damage * 2)
        cap = self.c["growth"]["max_level"]
        self.game.weapons["ring"] = cap
        self.assertEqual(self.game.weapon_stats("ring")["radius"], radius + (cap - 1) * self.c["ring"]["radius_per_level"])

    def test_blades_orbit_count_damage_and_per_blade_cooldown(self):
        self.game.weapons["blades"] = 1
        self.game.spark_clock = 100
        self.c["bat"]["speed"] = 0
        bat = Enemy(0, 0, 10000)
        self.game.enemies = [bat]
        settings = self.c["blades"]
        ticks = round(settings["hit_interval"] / self.c["fixed_dt"])
        for _ in range(ticks):
            # Keep this enemy under blade 0 throughout the cooldown.
            angle = (self.game.elapsed + self.c["fixed_dt"]) / settings["period"] * math.tau
            bat.x, bat.y = math.cos(angle) * settings["orbit_radius"], math.sin(angle) * settings["orbit_radius"]
            self.game.step()
        self.assertEqual(bat.hp, 10000 - settings["damage"])
        angle = (self.game.elapsed + self.c["fixed_dt"]) / settings["period"] * math.tau
        bat.x, bat.y = math.cos(angle) * settings["orbit_radius"], math.sin(angle) * settings["orbit_radius"]
        self.game.step()
        self.assertEqual(bat.hp, 10000 - settings["damage"] * 2)
        self.game.weapons["blades"] = self.c["growth"]["max_level"]
        positions = self.game.blade_positions()
        self.assertEqual(len(positions), settings["count"] + len(settings["extra_blade_levels"]))
        for x, y in positions:
            self.assertAlmostEqual(math.hypot(x - self.game.x, y - self.game.y), settings["orbit_radius"])


if __name__ == "__main__":
    unittest.main()
