import math
import random
import unittest

from rules import Enemy, Game, load_config


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.c = load_config()
        self.game = Game(self.c, random.Random(7))

    def advance(self, seconds, target=None):
        for _ in range(round(seconds / self.c["fixed_dt"])):
            self.game.step(target)

    def test_movement_and_dead_zone(self):
        self.advance(1, (10000, 0))
        self.assertAlmostEqual(self.game.x, self.c["hero"]["speed"])
        previous = self.game.x
        self.game.step((previous + self.c["controls"]["stop_distance"], 0))
        self.assertEqual(self.game.x, previous)

    def test_spawn_circle_minimum_and_limit(self):
        self.game.spawn_enemies()
        self.assertEqual(len(self.game.enemies), min(self.c["spawning"]["max_per_second"], self.game.current_wave()["minimum_alive"]))
        for bat in self.game.enemies:
            self.assertAlmostEqual(math.hypot(bat.x, bat.y), self.c["spawning"]["radius"])
        for _ in range(30):
            self.game.spawn_enemies()
        self.assertEqual(len(self.game.enemies), min(self.game.current_wave()["minimum_alive"], self.c["spawning"]["max_alive"]))

    def test_spawn_waits_for_interval_and_removes_distant_bats(self):
        ticks = round(self.c["spawning"]["interval"] / self.c["fixed_dt"])
        for _ in range(ticks - 1):
            self.game.step()
        self.assertEqual(len(self.game.enemies), 0)
        self.game.step()
        self.assertGreater(len(self.game.enemies), 0)
        self.game.enemies = [Enemy(self.c["spawning"]["remove_distance"] + 1, 0, self.c["bat"]["hp"])]
        self.game.step()
        self.assertEqual(self.game.enemies, [])

    def test_contact_damage_and_cooldown(self):
        self.game.spark_clock = 100
        self.game.enemies = [Enemy(0, 0, self.c["bat"]["hp"])]
        self.game.step()
        hp = self.c["hero"]["hp"] - self.c["bat"]["damage"]
        self.assertEqual(self.game.hp, hp)
        ticks = round(self.c["contact_interval"] / self.c["fixed_dt"])
        for _ in range(ticks - 1):
            self.game.step()
        self.assertEqual(self.game.hp, hp)
        self.game.step()
        self.assertEqual(self.game.hp, hp - self.c["bat"]["damage"])

    def test_spark_targets_nearest_and_kills(self):
        self.game.enemies = [Enemy(150, 0, self.c["bat"]["hp"]), Enemy(0, 60, self.c["bat"]["hp"])]
        self.game.step()
        self.assertAlmostEqual(self.game.sparks[0].vx, 0)
        self.assertAlmostEqual(self.game.sparks[0].vy, self.c["spark"]["speed"])
        self.advance(0.2)
        self.assertEqual(self.game.kills, 1)

    def test_game_over_freezes_and_new_game_resets(self):
        self.game.spark_clock = 100
        self.game.hp = self.c["bat"]["damage"]
        self.game.enemies = [Enemy(0, 0, self.c["bat"]["hp"])]
        self.game.step()
        self.assertTrue(self.game.game_over)
        self.assertEqual(self.game.hp, 0)
        elapsed = self.game.elapsed
        self.game.step((1000, 0))
        self.assertEqual(self.game.elapsed, elapsed)
        fresh = Game(self.c)
        self.assertFalse(fresh.game_over)
        self.assertEqual(fresh.hp, self.c["hero"]["hp"])
        self.assertEqual(fresh.kills, 0)
        self.assertEqual(fresh.enemies, [])

    def test_damage_events_and_kill_are_reported_once(self):
        enemy = Enemy(100, 0, self.c["bat"]["hp"])
        damage = max(self.c["spark"]["damage"], enemy.hp)
        self.game._damage(enemy, damage)
        self.game._damage(enemy, damage)
        events = self.game.pop_events()
        self.assertEqual([event.kind for event in events], ["hit", "death"])
        self.assertEqual(events[0].amount, damage)
        self.assertEqual((events[0].x, events[0].y), (enemy.x, enemy.y))
        self.assertEqual(events[1].enemy_kind, enemy.kind)
        self.assertEqual(self.game.kills, 1)
        self.assertEqual(len(self.game.gems), 1)
        self.assertEqual(self.game.pop_events(), [])

    def test_fatal_contact_reports_actual_hp_loss_and_end_once(self):
        self.game.spark_clock = 100
        self.game.hp = self.c["bat"]["damage"] / 2
        previous_hp = self.game.hp
        self.game.enemies = [Enemy(0, 0, self.c["bat"]["hp"])]
        self.game.step()
        events = self.game.pop_events()
        self.assertEqual([event.kind for event in events], ["hurt", "game_over"])
        self.assertEqual(events[0].amount, previous_hp)
        self.game.step()
        self.assertEqual(self.game.pop_events(), [])


if __name__ == "__main__":
    unittest.main()
